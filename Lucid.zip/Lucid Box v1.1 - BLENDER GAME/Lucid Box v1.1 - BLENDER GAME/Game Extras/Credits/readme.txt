v1.1 update. Now with a Level Editor and three special levels!


Created in Blender 2.76

All of the game is by me, mrow484



Music by mrow484

Controls from tutorials on YouTube titled "How to Make a Basic Game in Blender" by SuperGloop





Thanks for playing! :)
I hope you enjoyed it/
